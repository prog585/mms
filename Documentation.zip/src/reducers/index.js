import { combineReducers } from 'redux';

import assets from './assets';

export const reducers = combineReducers({ assets });